<?php
/* vim: set expandtab tabstop=4 shiftwidth=4: */
// +----------------------------------------------------------------------+
// | HTML_Page2                                                           |
// +----------------------------------------------------------------------+
// | Copyright (c) 1997 - 2004 The PHP Group                              |
// +----------------------------------------------------------------------+
// | This source file is subject to version 3.0 of the PHP license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available at through the world-wide-web at                           |
// | http://www.php.net/license/3_0.txt.                                  |
// | If you did not receive a copy of the PHP license and are unable to   |
// | obtain it through the world-wide-web, please send a note to          |
// | license@php.net so we can mail you a copy immediately.               |
// +----------------------------------------------------------------------+
// | Author:  Klaus Guenther <klaus@capitalfocus.org>                     |
// +----------------------------------------------------------------------+
//
// $Id$

/**
 * This file contains an array of namespace declarations.
 * These declarations have been taken directly from the w3c website:
 * http://www.w3c.org/
 * 
 * @package HTML_Page2
 * @author  Klaus Guenther <klaus@capitalfocus.org>
 */

// Array of namespace declarations:
$namespace['xhtml']['1.0'][] = 'http://www.w3.org/1999/xhtml';
$namespace['xhtml']['basic']['1.0'][] = 'http://www.w3.org/1999/xhtml';
$namespace['xhtml']['print']['1.0'][] = 'http://www.w3.org/1999/xhtml';
$namespace['xhtml']['1.1'][] = 'http://www.w3.org/1999/xhtml';
$namespace['xhtml']['2.0'][] = 'http://www.w3.org/2002/06/xhtml2';

?>
