<?php
/**
 * An exception thrown by PEAR_Size when it encounters an unrecoverable error.
 *
 * PHP version 5
 *
 * @category PEAR
 * @package  PEAR_Size
 * @author   Ken Guest <ken@linux.ie>
 * @license  LGPL (see http://www.gnu.org/licenses/lgpl.html)
 * @version  CVS: $Id: Size_Exception.php,v 1.1 2008/04/03 23:40:50 kguest Exp $
 * @link     http://pear.php.net/package/PEAR_Size
 */

require_once 'PEAR/Exception.php';

/**
 * An exception thrown by PEAR_Size when it encounters an unrecoverable error.
 *
 * @category  PEAR
 * @package   PEAR_Size
 * @author    Ken Guest <ken@linux.ie>
 * @copyright 2008 Ken Guest
 * @license   LGPL (see http://www.gnu.org/licenses/lgpl.html)
 * @version   Release: 0.1.9
 * @link      http://pear.php.net/package/PEAR_Size
 */
class PEAR_Size_Exception extends PEAR_Exception
{

}

?>
