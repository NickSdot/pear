<?php

require_once 'Crypt/GPG.php';

$gpg = new Crypt_GPG(
	array(
		'debug' => true,
		'homedir' => '/home/gauthierm/crypt-gpg-home',
	)
);

$data = <<<DATA
-----BEGIN PGP MESSAGE-----
Version: GnuPG v2.0.14 (GNU/Linux)

owEBOgHF/pANAwACAUbF7MvhjCqtAcsKYgBRLoxLdGVzdIkBHAQAAQIABgUCUS6M
SwAKCRBGxezL4YwqrQx6B/9qIsxS1xt+YcbXRRc2sHmqgnpc7gLoNGPIk72DSiGF
kGX3QvaB/WoUeTT5zxeFP2/TLqSxynTpPjMfWRYFW7FhZ/NDD1AvljwMN3MzaAih
/b7mJ9mM36vwi0elwx6gCVXqK1IDjKhCR5PA20upZTJvoXMMgxRXIKVSr5g9I3aS
qMcJlwLPH8AmO6r58L1oxxwyYUrAYt8NUyeXNYnpzghX2Do7p3puXykwZTj1cArO
Wz4P8dTY4WmNiA0wGl6aqv0EwfJVzeXfZzt07j40q4YlPR6puRXSy1n5EMLYPsRx
Rgq7zhSXcGkGmUtHQwip7A93DfLq7SOsRP0UryJ380Up
=NGOD
-----END PGP MESSAGE-----
DATA;

var_dump($gpg->verify($data));
