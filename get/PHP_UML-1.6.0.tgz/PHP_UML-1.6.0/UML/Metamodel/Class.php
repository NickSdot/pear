<?php
/**
 * PHP_UML (MOF-like metamodel of language PHP)
 *
 * PHP version 5
 * 
 * @category   PHP
 * @package    PHP_UML
 * @subpackage Metamodel
 * @author     Baptiste Autin <ohlesbeauxjours@yahoo.fr> 
 * @license    http://www.gnu.org/licenses/lgpl.html LGPL License 3
 * @version    SVN: $Revision: 135 $
 * @link       http://pear.php.net/package/PHP_UML
 * @link       http://www.omg.org/mof/
 * @since      $Date: 2009-11-30 01:21:11 +0100 (lun., 30 nov. 2009) $
 */

/**
 * Meta-Class
 *
 */
class PHP_UML_Metamodel_Class extends PHP_UML_Metamodel_Classifier
{
    public $ownedAttribute = array();
    public $isInstantiable;
    public $implements = array();
}
?>
