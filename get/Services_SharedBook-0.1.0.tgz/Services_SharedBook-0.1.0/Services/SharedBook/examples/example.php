<?php

    require_once 'Services/SharedBook.php'; 

    // Please register at http://www.sharedbook.com/biz/dev/mydevaccount.html
    $my_book = new Services_SharedBook('<Your API>', 
                              '<Your secred word>');
    
    try
    {                          
        $my_book->authLogin();
        
        $my_book->bmsCreateInit('Crossing the ocean', 
                                'Chapters of the book', 
                                'Chapters text comes here');
                                
        $my_book->bmsCreatePublish();
        
        $my_book->bmsAddComment('JohnDoe', 
                                'Nice book!', 
                                'Love the book.');
        
        $my_book->bmsAddComment('Superman', 
                                'Great pictures', 
                                'Where did you buy the cam?');

        $my_book->bmsAddPhoto('photo1.jpg', 'Alex'); 
        $my_book->bmsAddPhoto('photo2.jpg', 'Alex'); 
        $my_book->bmsSetFrontCoverPhoto('photo3.jpg', 'Alex');
        $my_book->bmsSetBackCoverPhoto('photo4.jpg', 'Alex');  
        
        $my_book->bmsPublish();  
        $my_book->bookCreateInit();                        
                              
        $my_book->bookCreateSetDedication('This book is dedicated to PHP API');
        $my_book->bookCreatePublish();
        echo 'URL: '.$my_book->bookPreview();
    }
    catch (Services_SharedBook_Exception $e)
    {
        echo $e->getCode().' - '.$e->getMessage();
    }
?>