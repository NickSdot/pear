<?php

class TestClass
{
}

?>