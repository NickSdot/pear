alert('Loaded setInnerHTML.js');
