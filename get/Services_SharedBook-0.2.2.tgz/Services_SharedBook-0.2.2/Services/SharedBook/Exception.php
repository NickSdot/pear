<?php
/**
* OPEN API LICENSE
*
* Copyright (c) 2007 SharedBook.  All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification,are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright
*    notice, this list of conditions and the disclaimer below.
* 2. Redistributions in binary form must reproduce the above copyright
*    notice, this list of conditions and the disclaimer below in the
*    documentation and/or other materials provided with the distribution.
* 3. The name of SharedBook Ltd., SharedBook Inc., or the names of its
*    contributor may not be used to endorse or promote products derived from
*    this software without specific prior written permission
*
* Disclaimer
* THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR IMPLIED
* WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
* AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL SHAREDBOOK LTD
* AND SHAREDBOOK INC. BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
* OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
* ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
* POSSIBILITY OF SUCH DAMAGE.
*
*
* Services_SharedBook_Exception class for the Services_SharedBook package.
* Extends the normal exception class.
*
* PHP version 5
*
* @category Services
* @package  Services_SharedBook
* @author   Alex Lavrov <sharedbook.php@gmail.com>
* @license  http://www.php.net/license/3_0.txt  LGPL License 3.0
* @link     not yet
*
*/

require_once 'PEAR/Exception.php';

/**
* Services_SharedBook_Exception class for the Services_SharedBook package.
* Extends the normal exception class.
*
* PHP version 5
*
* @category Services
* @package  Services_SharedBook
* @author   Alex Lavrov <sharedbook.php@gmail.com>
* @license  http://www.php.net/license/3_0.txt  LGPL License
* @link     not yet
*
*/
class Services_SharedBook_Exception extends PEAR_Exception
{
    /**
    * Constructor of the class
    *
    * @param string $message Error message
    * @param string $code    Error code
    */
    public function __construct($message = null, $code = 0)
    {
        parent::__construct($message, $code);
    }
    
    
}
?>