<?php
/**
 * Config_Lite_Exception (Config/Lite/Exception.php)
 *
 * PHP version 5
 *
 * @file      Config/Lite/Exception.php
 * @category  Configuration
 * @package   Config_Lite
 * @author    Patrick C. Engel <info@pc-e.org>
 * @copyright 2010 info@pc-e.org
 * @license   http://www.gnu.org/copyleft/lesser.html  LGPL License 2.1
 * @version   SVN: $Id$
 * @link      https://github.com/pce/config_lite
 */


/**
 * Config_Lite_Exception
 *
 * Interface implemented by Exceptions
 *
 * @category  Configuration
 * @package   Config_Lite
 * @author    Patrick C. Engel <info@pc-e.org>
 * @copyright 2010 info@pc-e.org
 * @license   http://www.gnu.org/copyleft/lesser.html  LGPL License 2.1
 * @version   Release: 0.1.0
 * @link      https://github.com/pce/config_lite
 */

interface Config_Lite_Exception
{
}
