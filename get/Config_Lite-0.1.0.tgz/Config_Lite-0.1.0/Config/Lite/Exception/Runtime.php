<?php
/**
 * Config_Lite_Exception_Runtime (Config/Lite/Exception/Runtime.php)
 *
 * PHP version 5
 *
 * @file      Config/Lite/Exception/Runtime.php
 * @category  Configuration
 * @package   Config_Lite
 * @author    Patrick C. Engel <info@pc-e.org>
 * @copyright 2010 info@pc-e.org
 * @license   http://www.gnu.org/copyleft/lesser.html  LGPL License 2.1
 * @version   SVN: $Id$
 * @link      https://github.com/pce/config_lite
 */


/**
 * Config_Lite_Exception_Runtime
 *
 * implements Config_Lite_Exception
 *
 * @category  Configuration
 * @package   Config_Lite
 * @author    Patrick C. Engel <info@pc-e.org>
 * @copyright 2010 info@pc-e.org
 * @license   http://www.gnu.org/copyleft/lesser.html  LGPL License 2.1
 * @version   Release: 0.1.0
 * @link      https://github.com/pce/config_lite
 */

class Config_Lite_Exception_Runtime
              extends RuntimeException
              implements Config_Lite_Exception
{
}
