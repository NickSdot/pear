<?php
/*
   +----------------------------------------------------------------------+
   | PEAR Web site version 1.0                                            |
   +----------------------------------------------------------------------+
   | Copyright (c) 2004-2005 The PEAR Group                               |
   +----------------------------------------------------------------------+
   | This source file is subject to version 2.02 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available at through the world-wide-web at                           |
   | http://www.php.net/license/2_02.txt.                                 |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Martin Jansen <mj@php.net>                                   |
   +----------------------------------------------------------------------+
   $Id$
*/

response_header("Support - Icons");
?>


<p>What programming tool would be complete without a set of icons to
put on your webpage, telling the world what makes your site tick?</p>

<table cellpadding="5" cellspacing="1">
<tr bgcolor="#e0e0e0">
    <td><img src="/gifs/pear-power.gif" width="88" height="31" alt="Powered by PEAR, GIF format"  /><br /></td>
    <td>Powered by PEAR, GIF format<br />g<small>88 x 31 pixels<br />854 bytes<br /></small></td>
</tr>
<tr bgcolor="#e0e0e0">
    <td><img src="/gifs/pear-power.png" width="88" height="31" alt="Powered by PEAR, PNG format"  /><br /></td>
    <td>Powered by PEAR, PNG format<br />g<small>88 x 31 pixels<br />1445 bytes<br /></small></td>
</tr>
<tr bgcolor="#e0e0e0">
    <td><img src="/gifs/pear-icon.gif" width="32" height="32" alt="32x32 PEAR icon, GIF format"  /><br /></td>
    <td>32x32 PEAR icon, GIF format<br />g<small>32 x 32 pixels<br />412 bytes<br /></small></td>
</tr>
<tr bgcolor="#e0e0e0">
    <td><img src="/gifs/pear-icon.png" width="32" height="32" alt="32x32 PEAR icon, PNG format"  /><br /></td>
    <td>32x32 PEAR icon, PNG format<br />g<small>32 x 32 pixels<br />927 bytes<br /></small></td>
</tr>
<tr bgcolor="#e0e0e0">
    <td><img src="/gifs/pear-blogbutton1.png" width="80" height="15" alt="80x15 PEAR blog button, PNG format"  /><br /></td>
    <td>80x15 PEAR weblog button, PNG format<br />g<small>80 x 15 pixels<br />282 bytes<br /></small></td>
</tr>
<tr bgcolor="#e0e0e0">
    <td><img src="/gifs/pear-blogbutton2.png" width="80" height="15" alt="80x15 PEAR blog button, PNG format"  /><br /></td>
    <td>80x15 PEAR weblog button, PNG format<br />g<small>80 x 15 pixels<br />581 bytes<br /></small></td>
</tr>
<tr bgcolor="#e0e0e0">
    <td><img src="/gifs/pear-eps.png" width="90" height="45" alt="PEAR vector graphic, EPS format"  /><br /></td>
    <td><a href="pear.eps.gz">PEAR logo vector graphic</a>, EPS format<br /><small>compressed, variable size<br />16343 bytes</small></td>
</tr>
<tr bgcolor="#e0e0e0">
    <td><img src="/gifs/pear-poster.png" width="90" height="127" alt="PEAR poster, PDF format"  /><br /></td>
    <td><a href="/downloads/pear-poster.pdf">PEAR Poster</a>, PDF format<br /><small>for printing<br />18289 bytes</small></td>
</tr>
<tr bgcolor="#e0e0e0">
    <td colspan="2"><a href="/downloads/pear-folder.ico">PEAR Folder ICO</a> by Philippe Jausions <small>137750 bytes</small></td>
</tr>
<tr bgcolor="#e0e0e0">
    <td colspan="2"><a href="/downloads/pear-folder.svg">PEAR Folder SVG</a> by Philippe Jausions <small> 11635 bytes</small></td>
</tr>
<tr bgcolor="#e0e0e0">
    <td colspan="2"><a href="/downloads/pear-logos.svg">PEAR Logo SVG</a> by Philippe Jausions <small> 11343 bytes</small></td>
</tr>

</table>

<p><b>Note:</b> Please do not just include these icons directly but
download them and save them locally in order to keep HTTP traffic
low.</p>

<?php
response_footer();
