<script>
jQuery.each(mapMarkers, function() {
    map.removeLayer(this);
});
</script>
<?php
require_once('Services/OpenStreetMap.php');
$lat = null;
$lon = null;
$k = null;
$v = null;

if (isset($_GET['q'])) {
    $v = strpos($_GET['q'], '|');
    if ($v != false) {
        list($k, $v) = explode('|',$_GET['q']);
        $k = trim($k);
        $v = trim($v);
    } else {
        die();
    }
}

if (isset($_GET['lat'])) {
    $lat = $_GET['lat'];
}
if (isset($_GET['lat'])) {
    $lon = $_GET['lon'];
}
$osm = new Services_OpenStreetMap();
$osm->loadXML("./map.osm");
$results = $osm->search(array($k => $v));
echo "List of $k/$v\n";
echo "==================\n\n";

$oh = new Services_OpenStreetMap_OpeningHours();
foreach ($results as $result) {
    $name = $result->getTag('name');
    $addrStreet = $result->getTag('addr:street');
    $addrCity = $result->getTag('addr:city');
    $addrCountry = $result->getTag('addr:country');
    $addrHouseName = $result->getTag('addr:housename');
    $addrHouseNumber = $result->getTag('addr:housenumber');
    $openingHours = $result->getTag('opening_hours');
    $phone = $result->getTag('phone');
    $oh->setValue($openingHours);
    $open = $oh->isOpen();

    $line1 = ($addrHouseNumber) ? $addrHouseNumber : $addrHouseName;
    if ($line1 != null) {
        $line1 .= ', ';
    }
    echo  "$name\n";
    if ($result->getType() == 'node') {
        echo $result->getLat(), ',', $result->getLon(), "\n";
        echo "<script>";
        echo "var marker = L.marker([",$result->getLat(),", ",$result->getLon()," ]).addTo(map);";
        echo "marker.bindPopup(\"<b>", htmlspecialchars($name), "</b>\");";
        echo "mapMarkers.push(marker);";
        echo "map.panTo([",$result->getLat(),", ",$result->getLon()," ]);";
        echo "</script>";
    } elseif ($result->getType() == 'way' && $result->isClosed()) {
        $nodes = $result->getNodes();
        array_pop($nodes);
        $lat = 0;
        $lon = 0;
        foreach($nodes as $node) {
            $n = $osm->getNode($node);
            $lat += $n->getLat();
            $lon += $n->getLon();
        }
        echo $lat / sizeof($nodes),", ",$lon / sizeof($nodes), "\n";
        echo "<script>";
        echo "var marker = L.marker([",$lat / sizeof($nodes),", ",$lon / sizeof($nodes)," ]).addTo(map);";
        echo "marker.bindPopup(\"<b>", htmlspecialchars($name), "</b>\");";
        echo "mapMarkers.push(marker);";
        echo "map.panTo([",$lat / sizeof($nodes),", ",$lon / sizeof($nodes)," ]);";
        echo "</script>";

    }
    if ($line1 != null && $addrStreet != null) {
        echo "{$line1}{$addrStreet}\n";
    }
    if ($phone != null) {
        echo "<a href='tel:$phone'>$phone</a>\n";
    }
    if ($openingHours !== null) {
        echo  "$openingHours\n";
        echo "Open?: ";
        if ($open === null) {
            echo "Maybe\n";
        } elseif ($open == true) {
            echo "Yes\n";
        } else {
            echo "No\n";
        }
    }
    echo "\n\n";
}

?>
