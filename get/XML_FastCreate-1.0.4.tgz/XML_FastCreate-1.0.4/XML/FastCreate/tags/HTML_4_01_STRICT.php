<?php

/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */

/**
 * Manual list of tags for DTD HTML4.01 Strict 
 *
 * The overload system crash if Zend Optimizer is used. 
 * You can defined a list of tags to continue to use overload & Zend Optimizer
 * Here is a list a tags for this common DTD.
 *
 * PHP versions 4 and 5
 *
 * LICENSE: This source file is subject to version 3.0 of the PHP license
 * that is available through the world-wide-web at the following URI:
 * http://www.php.net/license/3_0.txt.  If you did not receive a copy of
 * the PHP License and are unable to obtain it through the web, please
 * send a note to license@php.net so we can mail you a copy immediately.
 *
 * @category   XML
 * @package    XML_FastCreate
 * @author     Guillaume Lecanu <Guillaume@dev.fr>
 * @copyright  1997-2005 The PHP Group
 * @license    http://www.php.net/license/3_0.txt  PHP License 3.0
 * @version    CVS: $Id$
 * @link       http://pear.php.net/package/XML_FastCreate
 */

$GLOBAALS['XML_FASTCREATE_NO_OVERLOAD'] = array(
	'sub',
	'sup',
	'span',
	'bdo',
	'br',
	'body',
	'ins',
	'del',
	'address',
	'div',
	'a',
	'map',
	'area',
	'link',
	'img',
	'object',
	'param',
	'hr',
	'p',
	'pre',
	'q',
	'blockquote',
	'dl',
	'dt',
	'dd',
	'ol',
	'ul',
	'li',
	'form',
	'label',
	'input',
	'select',
	'optgroup',
	'option',
	'textarea',
	'fieldset',
	'legend',
	'button',
	'table',
	'caption',
	'thead',
	'tfoot',
	'tbody',
	'colgroup',
	'col',
	'tr',
	'th',
	'td',
	'head',
	'title',
	'base',
	'meta',
	'style',
	'script',
	'noscript',
	'html',
);
?>
