<?php
// $Id: admin_gettext_po_test.php 245971 2007-11-10 00:02:50Z quipo $

require_once 'admin_gettext_test_base.php';

if (!defined('TEST_RUNNING')) {
    define('TEST_RUNNING', true);
    $test = &new TestOfAdminContainerGettextPO();
    $test->run(new HtmlReporter());
}
?>