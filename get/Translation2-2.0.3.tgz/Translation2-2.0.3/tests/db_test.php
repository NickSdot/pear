<?php
// $Id: db_test.php 219003 2006-08-29 09:54:36Z quipo $

require_once 'db_test_base.php';

if (!defined('TEST_RUNNING')) {
    define('TEST_RUNNING', true);
    $test = &new TestOfContainerDB();
    $test->run(new HtmlReporter());
}
?>