<?php
// $Id: translation2_include.php 172879 2004-11-17 13:57:00Z quipo $
require_once 'Translation2.php';
?>