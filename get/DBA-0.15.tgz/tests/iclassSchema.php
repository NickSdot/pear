<?php
	$iclass_schema = array(
	  'section' => array (
	                  'id' => array ('type' => 'integer',
                                     'autoincrement' => True,
                                     'default' => 0),
					  'activity_id' => array ('type' => 'integer'),
					  'name' => array ('type' => 'varchar'),
                      'course_number' => array ('type' => 'integer'),
                      'section_number' => array ('type' => 'integer'),
	                  'week_days' => array ('type' => 'set',
	                                        'domain' => array('Sun','Mon','Tues'
											                 ,'Wed','Thur','Fri'
															  ,'Sat')),
					  'meeting_count' => array ('type'=>'integer'),
					  'start_date' => array ('type'=>'timestamp'),
					  'end_date' => array ('type'=>'timestamp'),
					  'start_time' => array ('type'=>'timestamp'),
					  'end_time' => array ('type'=>'timestamp'),
					  'time_flexible' => array ('type'=>'bool'),
					  'date_flexible' => array ('type'=>'bool'),
					  'general_cost' => array ('type'=>'integer'),
					  'ut_cost' => array ('type'=>'integer'),
					  'canceled' => array('type'=>'bool'),
					  'full' => array('type'=>'bool')),

	  'course' => array (
	                  'id' => array ('type' => 'integer',
                                     'autoincrement' => True,
                                     'default' => 0),
					  'name' => array ('type' => 'varchar'),
                      'course_number' => array ('type' => 'integer'),
					  'description' => array ('type' => 'text'),
					  'image_url' => array ('type' => 'varchar'),
					  'new' => array ('type' => 'bool')),
	);
?>
