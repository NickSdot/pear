*************
Net_WebFinger
*************

WebFinger client library for PHP.

Discover meta data about users by just their email address.
Discoverable data may be the user's OpenID, profile page URL,
link to portable contacts, hcard, foaf and other user pages.

Distributed social networks use WebFinger to distribute public encryption keys,
OStatus and Salmon URLs.

.. contents::

========
Examples
========

OpenID discovery
================
::

    <?php
    require_once 'Net/WebFinger.php';
    $wf = new Net_WebFinger();
    $react = $wf->finger('user@example.org');
    $openIdProvider = $react->get('http://specs.openid.net/auth/2.0/provider');
    if ($openIdProvider !== null) {
        echo 'OpenID provider found: ' . $openIdProvider . "\n";
    }
    ?>


Simple link access
==================
Some common link relations have a short name in Net_WebFinger. Those short
names can be used to access them more easily::

    <?php
    require_once 'Net/WebFinger.php';
    $wf  = new Net_WebFinger();
    $react = $wf->finger('user@example.org');
    if ($react->openid !== null) {
        echo 'OpenID provider found: ' . $react->openid . "\n";
    }
    ?>

Currently supported short names:

- ``contacts``
- ``hcard``
- ``openid``
- ``profile``
- ``xfn``


Accessing all links
===================
You can use ``foreach`` on the reaction object to get all links::

    <?php
    require_once 'Net/WebFinger.php';
    $wf = new Net_WebFinger();
    $react = $wf->finger('user@example.org');
    foreach ($react as $link) {
        echo 'Link: ' . $link->rel . ' to ' . $link->href . "\n";
    }
    ?>


Caching
=======
With caching, the retrieved host-meta files will be stored locally which leads
to faster lookup times when the same identifier (email address) is loaded again,
and when another identifier on the same host is retrieved.
::

    <?php
    require_once 'Net/WebFinger.php';
    require_once 'Cache.php';
    $wf = new Net_WebFinger();
    $wf->setCache(
        new Cache('file', array('cache_dir' => sys_get_temp_dir() . '/myapp'))
    );
    $react = $wf->finger('user@example.org');
    $openIdProvider = $react->get('http://specs.openid.net/auth/2.0/provider');
    ?>

Note: PEAR's Cache_Lite package does not support per-item lifetimes, so we cannot
use it: http://pear.php.net/bugs/bug.php?id=13297


XRD file access
===============
Sometimes the simple API is not enough and you need more details.
The result object gives you access to the ``.well-known/host-meta`` and user
XRD (LRDD) file objects::

    <?php
    require_once 'Net/WebFinger.php';
    $wf  = new Net_WebFinger();
    $react = $wf->finger('user@example.org');

    $openIdLink = $react->userXrd->get('http://specs.openid.net/auth/2.0/provider');
    echo $openIdLink->getTitle('de') . ':' . $openIdLink->href . "\n";

    foreach ($react->hostMetaXrd as $link) {
        echo $link->rel . ': ' . $link->href . "\n";
    }
    ?>


Security
========
The underlying XRD files will be retrieved via SSL when possible, with fallback
to normal HTTP. In the latter case, the XRD files need to have valid signatures
in order to be seen as secure.

The XRD subject is also verified. When it does not match the host name of the
email address, then the information are seen as insecure.

You should not trust the information if they are not secure.

::

    <?php
    require_once 'Net/WebFinger.php';
    $wf  = new Net_WebFinger();
    $react = $wf->finger('user@example.org');
    if (!$react->secure) {
        die("Those data may not be trusted\n");
    }


Custom HTTP adapter
===================
By default, the HTTP(S) XRD files are loaded by XML_XRD internally using
``simplexml_load_file``, which emits PHP Warnings when the files are not found
or other HTTP errors occur.

To work around that limitation, or to set some custom HTTP request headers,
you may use an own HTTP adapter that's used to fetch the files::


    <?php
    require_once 'HTTP/Request2.php';
    require_once 'Net/WebFinger.php';

    $req = new HTTP_Request2();
    $req->setConfig('follow_redirects', true);//needed for full compatibility
    $req->setHeader('User-Agent', 'MyApp 1.42');

    $wf = new Net_WebFinger();
    $wf->setHttpClient($req);
    $react = $wf->finger('foo@example.org');



=======
Testing
=======
You can use this identifiers to test the WebFinger functionality on various
providers:

- Gmail: evalpaul@gmail.com
- Yahoo: mcorne@yahoo.com
- AOL: M4dSquirrels@aol.com
- other:

  - cweiske@cweiske.de
  - darron@froese.org https://github.com/intridea/redfinger/issues/2

- diaspora: kevinkleinman@joindiaspora.com
- status.net: singpolyma@identi.ca


=====
Links
=====

References
==========

- `Webfinger mailing list`__
- `First specification`__
- `Common link relations`__
- `IETF draft`__
- http://hueniverse.com/2009/09/implementing-webfinger/
- http://hueniverse.com/2009/09/openid-and-lrdd/
- http://paulosman.me/2010/02/01/google-webfinger.html Google have since rolled out WebFinger support for everyone with a Google Profile.
- `Finger history`__
- `XRD 1.0 specification`__ 

__ http://groups.google.com/group/webfinger
__ http://code.google.com/p/webfinger/wiki/WebFingerProtocol
__ http://code.google.com/p/webfinger/wiki/CommonLinkRelations
__ http://www.ietf.org/id/draft-jones-appsawg-webfinger-00.txt
__ http://www.rajivshah.com/Case_Studies/Finger/Finger.htm
__ http://docs.oasis-open.org/xri/xrd/v1.0/xrd-1.0.html


Alternate implementations
=========================

- Ruby:

  - Redfinger__
  - Webfinger__

- Perl: `WWW::Finger::Webfinger`__
- PHP: discovery-php__ 
- PHP Wordpress plugin: Blogpost__, `webfinger-profile plugin`__

__ http://intridea.com/2010/2/12/redfinger-a-ruby-webfinger-gem
__ http://rubyforge.org/projects/webfinger/
__ http://search.cpan.org/~tobyink/WWW-Finger-0.101/lib/WWW/Finger/Webfinger.pm
__ https://github.com/walkah/discovery-php
__ http://blog.duthied.com/2011/08/30/webfinger-profile-plugin/
__ http://wordpress.org/extend/plugins/webfinger-profile/
